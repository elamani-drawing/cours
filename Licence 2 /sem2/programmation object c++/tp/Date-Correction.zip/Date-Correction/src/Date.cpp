#include "Date.h"
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

std::ostream &operator<<(std::ostream &out, const Date &date) {
  cout << setw(2) << setfill('0') << date.d_ << "/"
       << setw(2) << setfill('0') << date.m_ << "/" << date.y_;
  return out;
}

std::istream &operator>>(std::istream &in, Date &date) {
  string s;
  in >> s;
  date = s.c_str();
  return in;
}

bool bissextile(int y) {
  return (y > 0) && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0);
}

bool verify(int y, int m, int d) {
  if (y != 0 && m > 0 && m <= 12 && d > 0) {
    switch (m) {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:return d <= 31;
    case 4:
    case 6:
    case 9:
    case 11:return d <= 30;
    case 2:return bissextile(y) ? d <= 29 : d <= 28;
    default:return false;
    }
  }
  return false;
}

Date::Date() : d_(1), m_(1), y_(1970) {
}

Date::Date(const Date &date) : d_(date.d_), m_(date.m_), y_(date.y_) {
}

Date::Date(const char *date) {
  string ds;
  string ms;
  string ys;
  size_t p = 0;
  string s = date;
  while (p < s.size()) {
    if (s[p] != '/') {
      ds += s[p++];
    } else {
      ++p;
      break;
    }
  }
  while (p < s.size()) {
    if (s[p] != '/') {
      ms += s[p++];
    } else {
      ++p;
      break;
    }
  }
  while (p < s.size()) {
    ys += s[p++];
  }
  int d = 0;
  int m = 0;
  int y = 0;
  stringstream ssd(ds);
  ssd >> d;
  stringstream ssm(ms);
  ssm >> m;
  stringstream ssy(ys);
  ssy >> y;
  if (!verify(y, m, d)) {
    cout << "*** Erreur : " << d << "/" << m << "/" << y << " ***" << endl;
    y_ = 1970;
    m_ = 1;
    d_ = 1;
  }
  d_ = d;
  m_ = m;
  y_ = y;
}

Date::Date(int y, int m, int d) : d_(d), m_(m), y_(y) {
  if (!verify(y, m, d)) {
    cout << "*** Erreur : " << d << "/" << m << "/" << y << " ***" << endl;
    y_ = 1970;
    m_ = 1;
    d_ = 1;
  }
}

Date::~Date() {
}

Date &Date::operator=(const char *date) {
  string ds;
  string ms;
  string ys;
  size_t p = 0;
  string s = date;
  while (p < s.size()) {
    if (s[p] != '/') {
      ds += s[p++];
    } else {
      ++p;
      break;
    }
  }
  while (p < s.size()) {
    if (s[p] != '/') {
      ms += s[p++];
    } else {
      ++p;
      break;
    }
  }
  while (p < s.size()) {
    ys += s[p++];
  }
  int d = 0;
  int m = 0;
  int y = 0;
  stringstream ssd(ds);
  ssd >> d;
  stringstream ssm(ms);
  ssm >> m;
  stringstream ssy(ys);
  ssy >> y;
  if (!verify(y, m, d)) {
    cout << "*** Erreur : " << d << "/" << m << "/" << y << " ***" << endl;
    y_ = 1970;
    m_ = 1;
    d_ = 1;
  }
  d_ = d;
  m_ = m;
  y_ = y;
  return *this;
}

Date &Date::operator++() {
  incr_();
  return *this;
}

Date Date::operator++(int) {
  Date date = *this;
  incr_();
  return date;
}

Date &Date::operator--() {
  decr_();
  return *this;
}

Date Date::operator--(int) {
  Date date = *this;
  decr_();
  return date;
}

void Date::decr_() {
  switch (m_) {
  case 1:
    if (d_ == 1) {
      d_ = 31;
      m_ = 12;
      if (y_ == 1)
        y_ = -1;
      else
        --y_;
    } else {
      --d_;
    }
    break;
  case 5:
  case 7:
  case 8:
  case 10:
  case 12:
    if (d_ == 1) {
      d_ = 30;
      --m_;
    } else {
      --d_;
    }
    break;
  case 4:
  case 6:
  case 9:
  case 11:
    if (d_ == 1) {
      d_ = 31;
      --m_;
    } else {
      --d_;
    }
    break;
  case 3:
    if (d_ == 1) {
      if (bissextile(y_))
        d_ = 29;
      else
        d_ = 28;
      --m_;
    } else {
      --d_;
    }
    break;
  default:break;
  }
}

void Date::incr_() {
  switch (m_) {
  case 1:
  case 3:
  case 5:
  case 7:
  case 8:
  case 10:
    if (d_ == 31) {
      d_ = 1;
      ++m_;
    } else {
      ++d_;
    }
    break;
  case 4:
  case 6:
  case 9:
  case 11:
    if (d_ == 30) {
      d_ = 1;
      ++m_;
    } else {
      ++d_;
    }
    break;
  case 2:
    if (d_ < 28) {
      ++d_;
      break;
    }
    if (d_ == 29) {
      d_ = 1;
      ++m_;
      break;
    }
    if (bissextile(y_)) {
      if (d_ == 28) {
        ++d_;
        break;
      }
    } else {
      if (d_ == 28) {
        d_ = 1;
        ++m_;
        break;
      }
    }
    break;
  case 12:
    if (d_ == 31) {
      d_ = 1;
      m_ = 1;
      if (y_ == -1)
        y_ = 1;
      else
        ++y_;
    } else {
      ++d_;
    }
    break;
  default:break;
  }
}
