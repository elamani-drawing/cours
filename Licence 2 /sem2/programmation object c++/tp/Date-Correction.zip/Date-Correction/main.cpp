#include "Date.h"
#include <iostream>
using namespace std;

int main() {
  Date d0("21/12/2012");
  cout << "(Test 1) d0:" << d0 << endl;
  Date d1;
  d1  = "27/02/2020";
  cout << "(Test 2) d1:" << d1 << endl;
  Date d2(d1--);
  cout << "(Test 3) d1:" << d1 << endl;
  cout << "(Test 3) d2:" << d2 << endl;
  Date d3(d2++);
  cout << "(Test 4) d2:" << d2 << endl;
  cout << "(Test 4) d3:" << d3 << endl;
  d2 = ++d3;
  cout << "(Test 5) d2:" << d2 << endl;
  cout << "(Test 5) d3:" << d3 << endl;
  Date d4;
  cout << "(Test 6) d4:" << d4 << endl;
  cin >> d4; // Entrer une date valide comme 11/11/-1111
  cout << "(Test 7) d4:" << d4 << endl;
  Date d5;
  cin >> d5; // Entrer une date invalide comme 456/-097/0
  cout << "(Test 8) d5:" << d5 << endl;
  return 0;
}
