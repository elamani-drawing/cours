#ifndef DATE_H
#define DATE_H

#include <iostream>
#include <string>

class Date {
  friend std::ostream &operator<<(std::ostream &, const Date &);
  friend std::istream &operator>>(std::istream &, Date &);
public:
  Date();
  Date(const Date &);
  Date(const char *);
  Date(int, int, int);
  virtual ~Date();
  Date &operator=(const char *);
  Date &operator++();
  Date operator++(int);
  Date &operator--();
  Date operator--(int);
private:
  void decr_();
  void incr_();
  int d_;
  int m_;
  int y_;
};

#endif // DATE_H
