#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main() {
    ifstream ifs("mots.txt");
    ofstream ofs("mots-inv.txt");
    vector<string> v;
    while (ifs.good()) {
        string tmp;
        ifs >> tmp;
        v.push_back(tmp);
    }
    for (size_t i = v.size(); i > 0; --i) {
        ofs << v[i - 1] << endl;
    }
}
