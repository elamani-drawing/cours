#include <fstream>
#include <iostream>
#include <string>
using namespace std;

bool rechercher(const string &, ifstream &);

int main() {
    ifstream ifs("mots.txt");
    string mot;
    for (;;) {
        cout << "Entrer un mot : ";
        if (cin >> mot && mot != "//FIN") {
            if (rechercher(mot, ifs)) {
                cout << "Oui, " << mot << " existe dans le fichier." << endl;
            } else {
                cout << "Non, " << mot << " n'existe pas dans le fichier." << endl;
            }
        } else {
            break;
        }
    }
}

bool rechercher(const string &mot, ifstream &ifs) {
    ifs.clear();
    ifs.seekg(0, ios::beg);
    // TODO
    while (ifs.good()) {
        string tmp;
        if (ifs >> tmp && tmp == mot) {
            return true;
        }
    }
    return false;
    // End TODO
}
