#include <iostream>
#include <string>
using namespace std;

int real_ = 0;
int size_ = 0;

string read() {
    string w;
    cout << "Entrer un mot (//FIN pour finir) : ";
    // (1)
    cin >> w;
    if (w == "//FIN") {
        w = "";
    }
    // Fin (1)
    return w;
}

void resize(string *&p) {
    if (!p) {
        // (2)
        real_ = 2;
        p = new string[real_];
        // Fin (2)
    }
    if (size_ == real_) {
        // (3)
        real_ *= 2;
        string *tmp = new string[real_];
		// Attention : memcpy() ne fonctionne pas ici ! Pourquoi ?
        for (int i = 0; i < size_; ++i) {
            tmp[i] = p[i];
        }
        delete[] p;
        p = tmp;
        // Fin (3)
    }
}

void add(string *&p, const string &s) {
    resize(p);
    p[size_++] = s;  // C'est size++, ++size ne fonctionne pas !
}

int main() {
    string *words = nullptr; // => 0 ou NULL
    string word = read();
    while (word != "") {
        add(words, word);
        word = read();
    }
    // (4)
    for (int i = 0; i < size; ++i) {
        cout << words[i] << endl;
    }
    // Fin (4)
    // (5)
    delete[] words;
    // Fin (5)
    return 0;
}

/*
(6)
Ici la réponse à la question.

Le paramètre 'string *&a' signifie que 'a' est une référence d'un pointeur de string
 dont la valeur doit être modifiée dans la fcontion, si on le remplace par 'string *a'
 alors on ne peut plus modifier la valeur de 'a'.
 
*/
