#include <fstream>
#include <iostream>
#include <map>
#include <string>
using namespace std;

string clean(const string &);

int main() {
    ifstream ifs("article.txt");
    map<string, int> mots;
    while (ifs.good()) {
        string tmp;
        ifs >> tmp;
        tmp = clean(tmp);
        if (!tmp.empty()) {
            ++mots[tmp];
        }
    }
    // C++11
    for (auto &p : mots) {
        cout << p.first << ":" << p.second << endl;
    }
    // C++98
    for (map<string, int>::iterator it = mots.begin(); it != mots.end(); ++it) {
        cout << it->first << ":" << it->second << endl;
    }
}

string clean(const string &mot) {
    char signes[] = {',', '.', ';', '?', '!'};
    char c = mot[mot.size() - 1];
    bool signe = false;
    string tmp;
    // C++11
    for (auto x : signes) {
        if (c == x) {
            signe = true;
            break;
        }
    }
    // C++98
    for (size_t i = 0; i < 5; ++i) {
        if (c == signes[i]) {
            signe = true;
            break;
        }
    }
    if (signe) {
        for (size_t i = 0; i < mot.size() - 1; ++i) {
            tmp += mot[i];
        }
    } else {
        tmp = mot;
    }
    return tmp;
}
