#include <fstream>
#include <iostream>
#include <map>
#include <string>
using namespace std;

int main() {
    ifstream ifs("article.txt");
    map<string, int> mots;
    while (ifs.good()) {
        string tmp;
        ifs >> tmp;
        ++mots[tmp];
    }
    // C++11
    for (auto &p : mots) {
        cout << p.first << ":" << p.second << endl;
    }
    // C++98
    for (map<string, int>::iterator it = mots.begin(); it != mots.end(); ++it) {
        cout << it->first << ":" << it->second << endl;
    }
}
