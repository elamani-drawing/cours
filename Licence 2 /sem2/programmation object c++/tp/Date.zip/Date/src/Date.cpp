#include "Date.h"
#include <iostream>
using namespace std;

std::ostream &operator<<(std::ostream &out, const Date &date) {
  // TODO (1)
}

std::istream &operator>>(std::istream &in, Date &date) {
  // TODO (2)
}

bool bissextile(int y) {
    return (y > 0) && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0);
}

bool verify(int y, int m, int d) {
    if (y != 0 && m > 0 && m <= 12 && d > 0) {
      switch (m) {
      case 1:
      case 3:
      case 5:
      case 7:
      case 8:
      case 10:
      case 12:return d <= 31;
      case 4:
      case 6:
      case 9:
      case 11:return d <= 30;
      case 2:return bissextile(y) ? d <= 29 : d <= 28;
      default:return false;
      }
    }
    return false;
}

Date::Date() : d_(1), m_(1), y_(1970) {
}

Date::Date(const Date &date) : d_(date.d_), m_(date.m_), y_(date.y_) {
}

Date::Date(const char *date) {
  // TODO (3)
}

Date::Date(int y, int m, int d) : d_(d), m_(m), y_(y) {
  if (!verify(y, m, d)) {
    cout << "*** Erreur : " << d << "/" << m << "/" << y << " ***" << endl;
    y_ = 1970;
    m_ = 1;
    d_ = 1;
  }
}

Date::~Date() {
}

Date &Date::operator=(const char *date) {
  // TODO (4)
  return *this;
}

Date &Date::operator++() {
  // TODO (5)
  return *this;
}

Date Date::operator++(int) {
  Date date = *this;
  // TODO (6)
  return date;
}

Date &Date::operator--() {
  // TODO (7)
  return *this;
}

Date Date::operator--(int) {
  Date date = *this;
  // TODO (8)
  return date;
}

void Date::decr_() {
  // TODO
}

void Date::incr_() {
  // TODO
}
