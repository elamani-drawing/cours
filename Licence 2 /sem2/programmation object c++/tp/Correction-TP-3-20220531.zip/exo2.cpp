#include <iostream>
using namespace std;

void array_init(int x[], int n, int v) {
    cout << "sizeof(x[]) en fonction : " << sizeof(x) << endl;
    for (int i = 0; i < n; ++i)
        x[i] = v;
}

int main() {
    int y[200];
    int x[5];
    cout << "sizeof(x[5]) : " << sizeof(x) << endl;
    array_init(x, 55, 1);
    for (int i = 0; i < 5; ++i)
        cout << "x[" << i << "]=" << x[i] << endl;
}
