#include <iostream>
using namespace std;

int main() {
    int x[5];
    int *ptr;
    for (int i = 0; i < 5; ++i)
        x[i] = 0;
    ptr = x;
    cout << "1) ptr = " << ptr << ", *ptr = " << *ptr << ", (*ptr)++ = " << (*ptr)++ << ", ptr = " << ptr << ", *ptr = " << *ptr << endl;
    for (int i = 0; i < 5; ++i)
        x[i] = 0;
    ptr = x;
    cout << "2) ptr = " << ptr << ", *ptr = " << *ptr << ", ++(*ptr) = " << ++(*ptr) << ", ptr = " << ptr << ", *ptr = " << *ptr << endl;
    for (int i = 0; i < 5; ++i)
        x[i] = 0;
    ptr = x;
    cout << "3) ptr = " << ptr << ", *ptr = " << *ptr << ", *(ptr++) = " << *(ptr++) << ", ptr = " << ptr << ", *ptr = " << *ptr << endl;
    for (int i = 0; i < 5; ++i)
        x[i] = 0;
    ptr = x;
    cout << "4) ptr = " << ptr << ", *ptr = " << *ptr << ", *(++ptr) = " << *(++ptr) << ", ptr = " << ptr << ", *ptr = " << *ptr << endl;
    for (int i = 0; i < 5; ++i)
        x[i] = 0;
    ptr = x;
    cout << "5) ptr = " << ptr << ", *ptr = " << *ptr << ", *ptr++ = " << *ptr++ << ", ptr = " << ptr << ", *ptr = " << *ptr << endl;
    for (int i = 0; i < 5; ++i)
        x[i] = 0;
    ptr = x;
    cout << "6) ptr = " << ptr << ", *ptr = " << *ptr << ", ++*ptr = " << ++*ptr << ", ptr = " << ptr << ", *ptr = " << *ptr << endl;
    for (int i = 0; i < 5; ++i)
        x[i] = 0;
    ptr = x;
    cout << "7) ptr = " << ptr << ", *ptr = " << *ptr << ", *++ptr = " << *++ptr << ", ptr = " << ptr << ", *ptr = " << *ptr << endl;
}
