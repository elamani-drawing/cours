#include <iostream>
#include <string>
using namespace std;

int main() {
    char s[] = "ABC";
	char *x = s;
    while (*x)
        ++x;
    while (x > s)
        cout << *--x;
    cout << endl;
}