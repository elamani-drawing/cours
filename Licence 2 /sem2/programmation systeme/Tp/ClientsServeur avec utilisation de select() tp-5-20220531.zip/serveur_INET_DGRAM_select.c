/*********************************************************************************************
    serveur_INET_DGRAM_select.c : programme serveur utilisant des sockets dans le domaine INET 
				  et de type DGRAM avec select()

    Reference : TP n� Hors serie
                             -------------------
    begin	: 21/04/2020
    copyright	: (C) 2020 by Mohamed Taghelit
    email	: taghelit@univ-tours.fr

    Compiler 	: gcc (GCC) 4.4.7 20120313 (Red Hat 4.4.7-4)
 ********************************************************************************************/

/*********************************************************************************************
 *                                                                                           *
 *	ENONCE : Programmer l'exemple de communication, par socket, entre deux               *
 *	processus (un serveur et un (ou +) client) suivant :                                 *
 *                                                                                           *
 *	Le serveur est en attente de r�c�ption de deux types de requ�tes :                   *
 *	- REQUETE_COMPTER : dans ce cas, le serveur comptabilise le nombre d'octets dont est *
 *	  constitu� le texte qui accompagne la requ�te et renvoie ce nombre au client        *
 *	- REQUETE_MAJUSCULE : dans ce cas, le serveur transforme tous les caract�res         *
 *	  alphab�tiques en miniscule du texte, qui accompagne la requ�te, en caract�res      *
 *	  majuscules                                                                         *
 *                                                                                           *
 *	Chaque type de requ�tes doit �tre re�u sur une socket diff�rente. Le serveur doit    *
 *	se mettre en attente de r�c�ption de requ�tes sur ces deux sockets en utilisant la   *
 *	primitive select()                                                                   *
 *                                                                                           *
 *	Le client peut �mettre l'une ou l'autre des requ�tes et se met en attente de la      *
 *	r�ponse du serveur qu'il affiche.                                                    *
 *	Chaque requ�te du client est accompagn�e d'un texte ASCII.                           *
 *                                                                                           *
 *	REMARQUE :                                                                           *
 *	Ce programme est associ� au programme client_INET_DGRAM_select.c                     *
 *	Le processus serveur doit �tre lanc� avant le-s processus client.                    *
 *	On donnera en ligne de commande, au client, le site du serveur ("localhost" en local)*
 *	                                                                                     *
 ********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>


#define	REQUETE_COMPTER		1
#define	REQUETE_MAJUSCULE	2
#define	REPONSE_COMPTER		3
#define REPONSE_MAJUSCULE	4
#define ERREUR			5

#define TAILLE_TEXTE		124
#define TAILLE_NOM_SITE		64


int main()
{

int indice;

int fd_socket_compter;
int fd_socket_majuscule;

struct sockaddr_in socket_serveur_compter;
struct sockaddr_in socket_serveur_majuscule;

struct sockaddr_in socket_client;

fd_set  readfds;

socklen_t taille_socket;
size_t taille_texte;

int nb_desc, nb_desc_plus1;

char nom_site[TAILLE_NOM_SITE];
struct hostent *entree_site;


struct msg_reponse_compter {
	int taille;
	char vide[TAILLE_TEXTE - sizeof(int)];
};

struct msg_generic {
	int type;
	union corps_msg {
		char texte[TAILLE_TEXTE];
		struct msg_reponse_compter reponse_compter;
	} corps;
} message;

taille_socket = sizeof(socket_client);
taille_texte = TAILLE_TEXTE;

/* Phase creation et nommage sockets du serveur */

if ( gethostname(nom_site, TAILLE_NOM_SITE) == -1) {
	printf("Erreur GETHOSTNAME !\n");
	exit(-1);
	}

if ( (entree_site = gethostbyname(nom_site)) == NULL) {
	printf("Echec GETHOSTBYNAME !\n");
	exit(-1);
	}

bzero( (char *)&socket_serveur_compter, sizeof(socket_serveur_compter) );
bcopy( entree_site->h_addr, (char *)&socket_serveur_compter.sin_addr, entree_site->h_length);
socket_serveur_compter.sin_family = entree_site->h_addrtype;

bzero( (char *)&socket_serveur_majuscule, sizeof(socket_serveur_majuscule) );
bcopy( entree_site->h_addr, (char *)&socket_serveur_majuscule.sin_addr, entree_site->h_length);
socket_serveur_majuscule.sin_family = entree_site->h_addrtype;

socket_serveur_compter.sin_port = htons(2019);
socket_serveur_majuscule.sin_port = htons(2020);

if ( (fd_socket_compter = socket( AF_INET, SOCK_DGRAM, 0)) == -1 ) {
	printf("Echec creation socket compter\n");
	exit(-1);
	}

if ( (fd_socket_majuscule = socket( AF_INET, SOCK_DGRAM, 0)) == -1 ) {
	printf("Echec creation socket majuscule\n");
	exit(-1);
	}

if ( bind(fd_socket_compter, (struct sockaddr *)&socket_serveur_compter, sizeof(socket_serveur_compter)) == -1) {
	printf("Erreur BIND COMPTER !\n");
	exit(-1);
	}

if ( bind(fd_socket_majuscule, (struct sockaddr *)&socket_serveur_majuscule, sizeof(socket_serveur_majuscule)) == -1) {
	printf("Erreur BIND MAJUSCULE !\n");
	exit(-1);
	}

printf("Demarrage traitement .... Attente requetes !!\n");

nb_desc_plus1 = fd_socket_majuscule + 1;

for(;;) {

FD_ZERO(&readfds);
FD_SET(fd_socket_compter, &readfds);
FD_SET(fd_socket_majuscule, &readfds);


if ( (nb_desc = select( nb_desc_plus1, &readfds, NULL, NULL, NULL)) == -1) {
	printf("Erreur select\n");
	exit(-1);
	}

if ( FD_ISSET(fd_socket_compter, &readfds ) ) {
	recvfrom(fd_socket_compter, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_client, &taille_socket);

	switch ( message.type ) {
	case REQUETE_COMPTER:
		indice = 0;
		while ( (message.corps.texte[indice] != '\0') && (indice < TAILLE_TEXTE) )
		indice++;

		message.corps.reponse_compter.taille = indice;
		bzero(message.corps.reponse_compter.vide, TAILLE_TEXTE - sizeof(int));
		message.type = REPONSE_COMPTER;

		sendto(fd_socket_compter, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_client, taille_socket);
		break;

	default:
		message.type = ERREUR;
		strcpy(message.corps.texte, "TYPE MESSAGE INCONNU !!!");
		sendto(fd_socket_compter, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_client, taille_socket);
	}
}

if ( FD_ISSET(fd_socket_majuscule, &readfds ) ) {
	recvfrom(fd_socket_majuscule, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_client, &taille_socket);

	switch ( message.type ) {
	case REQUETE_MAJUSCULE:
		indice = 0;
		while ( (message.corps.texte[indice] != '\0') && (indice < TAILLE_TEXTE) ) {
		if ( (message.corps.texte[indice] >= 'a') && (message.corps.texte[indice] <= 'z') )
			message.corps.texte[indice] = message.corps.texte[indice] - 32 ;
		indice++;
		}

		message.type = REPONSE_MAJUSCULE;

		sendto(fd_socket_majuscule, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_client, taille_socket);
		break;

	default:
		message.type = ERREUR;
		strcpy(message.corps.texte, "TYPE MESSAGE INCONNU !!!");
		sendto(fd_socket_majuscule, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_client, taille_socket);


	}
}


}

return 0;

} 



