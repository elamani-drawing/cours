/*********************************************************************************************
    client_INET_DGRAM_select.c : programme client utilisant des sockets dans le domaine INET 
				  et de type DGRAM pour communiquer avec un serveur

    Reference : TP n� Hors serie
                             -------------------
    begin	: 21/04/2020
    copyright	: (C) 2020 by Mohamed Taghelit
    email	: taghelit@univ-tours.fr

    Compiler 	: gcc (GCC) 4.4.7 20120313 (Red Hat 4.4.7-4)
 ********************************************************************************************/

/*********************************************************************************************
 *                                                                                           *
 *	ENONCE : Programmer l'exemple de communication, par socket, entre deux               *
 *	processus (un serveur et un (ou +) client) suivant :                                 *
 *                                                                                           *
 *	Le serveur est en attente de r�c�ption de deux types de requ�tes :                   *
 *	- REQUETE_COMPTER : dans ce cas, le serveur comptabilise le nombre d'octets dont est *
 *	  constitu� le texte qui accompagne la requ�te et renvoie ce nombre au client        *
 *	- REQUETE_MAJUSCULE : dans ce cas, le serveur transforme tous les caract�res         *
 *	  alphab�tiques en miniscule du texte, qui accompagne la requ�te, en caract�res      *
 *	  majuscules                                                                         *
 *                                                                                           *
 *	Chaque type de requ�tes doit �tre re�u sur une socket diff�rente. Le serveur doit    *
 *	se mettre en attente de r�c�ption de requ�tes sur ces deux sockets en utilisant la   *
 *	primitive select()                                                                   *
 *                                                                                           *
 *	Le client peut �mettre l'une ou l'autre des requ�tes et se met en attente de la      *
 *	r�ponse du serveur qu'il affiche.                                                    *
 *	Chaque requ�te du client est accompagn�e d'un texte ASCII.                           *
 *                                                                                           *
 *	REMARQUE :                                                                           *
 *	Ce programme est associ� au programme serveur_INET_DGRAM_select.c                    *
 *	Le processus serveur doit �tre lanc� avant le-s processus client.                    *
 *	On donnera en ligne de commande, au client, le site du serveur ("localhost" en local)*
 *	                                                                                     *
 ********************************************************************************************/

//#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>


#define	REQUETE_COMPTER		1
#define	REQUETE_MAJUSCULE	2
#define	REPONSE_COMPTER		3
#define REPONSE_MAJUSCULE	4
#define ERREUR			5

#define TAILLE_TEXTE		124
#define TAILLE_NOM_SITE		64


int main(int argc, char **argv)
{

char *texte;
ssize_t octets_lus;

int fd_socket;

struct sockaddr_in socket_serveur_compter;
struct sockaddr_in socket_serveur_majuscule;
struct sockaddr_in socket_source;

socklen_t taille_socket, taille_socket_compter, taille_socket_majuscule;
int taille_texte;

struct hostent *entree_site;

struct msg_reponse_compter {
	int taille;
	char vide[TAILLE_TEXTE - sizeof(int)];
};

struct msg_generic {
	int type;
	union corps_msg {
		char texte[TAILLE_TEXTE];
		struct msg_reponse_compter reponse_compter;
	} corps;
} message;


taille_socket_compter = sizeof(socket_serveur_compter);
taille_socket_majuscule = sizeof(socket_serveur_majuscule);
taille_socket = sizeof(socket_source);
taille_texte = TAILLE_TEXTE;

texte = NULL;

if ( argc < 2 ) {
	printf("Introduire en parametre le nom du site du serveur\n");
	exit(0);
	}

/* Phase creation et nommage sockets du serveur */

if ( (entree_site = gethostbyname(argv[1])) == NULL) {
	printf("Echec GETHOSTBYNAME !\n");
	exit(-1);
	}

bzero( (char *)&socket_serveur_compter, sizeof(socket_serveur_compter) );
bcopy( entree_site->h_addr, (char *)&socket_serveur_compter.sin_addr, entree_site->h_length);
socket_serveur_compter.sin_family = entree_site->h_addrtype;

bzero( (char *)&socket_serveur_majuscule, sizeof(socket_serveur_majuscule) );
bcopy( entree_site->h_addr, (char *)&socket_serveur_majuscule.sin_addr, entree_site->h_length);
socket_serveur_majuscule.sin_family = entree_site->h_addrtype;

socket_serveur_compter.sin_port = htons(2019);
socket_serveur_majuscule.sin_port = htons(2020);


if ( (fd_socket = socket( AF_INET, SOCK_DGRAM, 0)) == -1 ) {
	printf("Echec creation socket client\n");
	exit(-1);
	}

/* Demarrage traitement .... ! */

for(;;) {

printf("Introduire un texte : ");
octets_lus = getline(&texte, (size_t *)&taille_texte, stdin);

strncpy(message.corps.texte, texte, octets_lus);
message.corps.texte[octets_lus - 1] = '\0';

printf("Quel service voulez-vous sur votre texte : \n\tCompter le nbr d'octets (1) ou Transformer en Majuscules (2) ? : ");
octets_lus = getline(&texte, (size_t *)&taille_texte, stdin);
texte[octets_lus - 1] = '\0';


message.type = atoi(texte);

if ( message.type == 1 ) {
	if (sendto(fd_socket, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_serveur_compter, taille_socket_compter) == -1){
	perror("ERREUR SENDTO 1"); 
	exit(-1);
	}
	recvfrom(fd_socket, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_source, &taille_socket);
	if ( message.type == REPONSE_COMPTER )
		printf("Mon texte comportait %d octets\n", message.corps.reponse_compter.taille);
	else
		printf("Message recu de type %d de contenu : %s\n", message.type, message.corps.texte);
	}
else	{
	if ( sendto(fd_socket, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_serveur_majuscule, taille_socket_majuscule) == -1){
	perror("ERREUR SENDTO 2"); 
	exit(-1);
	}
	recvfrom(fd_socket, &message, sizeof(struct msg_generic), 0, (struct sockaddr *)&socket_source, &taille_socket);
	if ( message.type == REPONSE_MAJUSCULE )
		printf("Mon texte en MAJUSCULES est : %s\n", message.corps.texte);
	else
		printf("Message recu de type %d de contenu : %s\n", message.type, message.corps.texte);
	}
}

return 0;

}



